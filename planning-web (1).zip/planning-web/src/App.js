import React, { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

const hours = Array.from({ length: 65 }, (_, i) => {
  const h = Math.floor((6 * 60 + i * 15) / 60);
  const m = (i * 15) % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
});

const days = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
const slotLabels = [
  { label: "Accueil 1", width: 120 },
  { label: "Accueil 2", width: 120 },
  { label: "Accueil 3", width: 120 },
  { label: "Accueil 4", width: 120 },
  { label: "AQUA", width: 120 },
  { label: "CYCLE", width: 120 },
  { label: "WELLNESS", width: 120 },
  { label: "ATHLETIC", width: 120 },
  { label: "SMART", width: 120 },
];

export default function PlanningWeb() {
  const [postes, setPostes] = useState(
    Array.from({ length: 20 }, (_, i) => ({
      name: `Salarié ${i + 1}`,
      color: `hsl(${(i * 18) % 360}, 70%, 75%)`
    }))
  );

  const [selectedColor, setSelectedColor] = useState(postes[0].color);
  const [planning, setPlanning] = useState(() => {
    const saved = localStorage.getItem("planningData");
    return saved ? JSON.parse(saved) : {};
  });

  const handleClick = (day, hour, slot) => {
    const key = `${day}-${hour}-${slot}`;
    setPlanning((prev) => {
      const newPlanning = {
        ...prev,
        [key]: prev[key] === selectedColor ? null : selectedColor
      };
      localStorage.setItem("planningData", JSON.stringify(newPlanning));
      return newPlanning;
    });
  };

  const handleExportJSON = () => {
    const blob = new Blob([JSON.stringify(planning, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "planning.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    const rows = postes.map((p) => [p.name, `${colorCounts[p.color]?.toFixed(2) || "0.00"} h`]);
    autoTable(doc, {
      head: [["Salarié", "Heures"]],
      body: rows
    });
    doc.save("planning.pdf");
  };

  const handleExportExcel = () => {
    const data = postes.map((p) => ({
      Salarié: p.name,
      Heures: colorCounts[p.color]?.toFixed(2) || "0.00"
    }));
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Planning");
    XLSX.writeFile(workbook, "planning.xlsx");
  };

  const colorCounts = useMemo(() => {
    const counts = {};
    Object.values(planning).forEach((color) => {
      if (!color) return;
      counts[color] = (counts[color] || 0) + 0.25;
    });
    return counts;
  }, [planning]);

  const updatePoste = (index, field, value) => {
    const updated = [...postes];
    updated[index][field] = value;
    setPostes(updated);
  };

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Planning Hebdomadaire</h1>

      <div className="flex flex-wrap gap-2">
        {postes.map((p, i) => (
          <div key={p.name} className="flex items-center gap-1">
            <input
              type="color"
              value={p.color}
              onChange={(e) => updatePoste(i, "color", e.target.value)}
              className="w-6 h-6"
            />
            <input
              type="text"
              value={p.name}
              onChange={(e) => updatePoste(i, "name", e.target.value)}
              className="border px-2 py-1 text-sm"
            />
            <Button onClick={() => setSelectedColor(p.color)} style={{ backgroundColor: p.color }}>
              Choisir
            </Button>
          </div>
        ))}

        <Button variant="outline" onClick={handleExportJSON}>Exporter JSON</Button>
        <Button variant="outline" onClick={handleExportExcel}>Exporter Excel</Button>
        <Button variant="outline" onClick={handleExportPDF}>Exporter PDF</Button>
      </div>

      <div className="overflow-auto">
        <table className="table-auto border mt-4">
          <thead>
            <tr>
              <th className="border px-2">Heure</th>
              {days.map((day) => (
                <th key={day} className="border px-4">
                  <div>{day}</div>
                  <div className="grid grid-cols-9 text-[10px] text-center">
                    {slotLabels.map((slot, idx) => (
                      <div
                        key={idx}
                        className="border-r last:border-none"
                        style={{ width: `${slot.width}px` }}
                      >
                        {slot.label}
                      </div>
                    ))}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {hours.map((hour) => (
              <tr key={hour}>
                <td className="border px-2 text-sm whitespace-nowrap align-top">{hour}</td>
                {days.map((day) => (
                  <td key={`${day}-${hour}`} className="border px-1 align-top">
                    <div className="grid grid-cols-9 gap-[1px]">
                      {slotLabels.map((slot, idx) => (
                        <div
                          key={idx}
                          className="h-4 cursor-pointer"
                          style={{
                            backgroundColor: planning[`${day}-${hour}-${idx}`] || "white",
                            width: `${slot.width}px`
                          }}
                          onClick={() => handleClick(day, hour, idx)}
                        ></div>
                      ))}
                    </div>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-2">Total d'heures par salarié</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2">
          {postes.map((p) => (
            <div key={p.name} className="flex items-center gap-2">
              <div className="w-4 h-4 rounded" style={{ backgroundColor: p.color }}></div>
              <span>{p.name} :</span>
              <span>{colorCounts[p.color]?.toFixed(2) || "0.00"} h</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
